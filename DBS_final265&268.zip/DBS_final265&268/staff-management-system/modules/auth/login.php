<?php
session_start();
include "../../config/db.php";

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $username = mysqli_real_escape_string($conn, trim($_POST['username']));
    $password = $_POST['password'];

    $sql = "SELECT * FROM admin WHERE username = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    if($row = mysqli_fetch_assoc($res)){
        // compare SHA2 hash (we stored SHA2 in SQL)
        $hash = hash('sha256', $password);
        if(hash_equals($row['password'], $hash)){
            // success
            $_SESSION['admin_id'] = $row['id'];
            $_SESSION['admin_user'] = $row['username'];
            header("Location: ../../pages/dashboard.php");
            exit;
        }
    }
    $_SESSION['login_error'] = "Invalid username or password.";
    header("Location: ../../pages/login.php");
    exit;
}
header("Location: ../../pages/login.php");
exit;
