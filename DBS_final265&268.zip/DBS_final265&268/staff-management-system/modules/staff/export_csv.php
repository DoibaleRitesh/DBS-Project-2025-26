<?php
include "../../config/db.php";
include "../../includes/auth_check.php"; // ensure admin

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=staff_export_'.date('Ymd_His').'.csv');

$output = fopen('php://output', 'w');
fputcsv($output, ['ID','Name','Email','Phone','Designation','Salary','Image','Created At']);

$search = '';
if(!empty($_GET['q'])) {
    $search = mysqli_real_escape_string($conn, $_GET['q']);
    $where = " AND (name LIKE '%$search%' OR email LIKE '%$search%' OR designation LIKE '%$search%')";
} else $where = '';

$designation = '';
if(!empty($_GET['designation'])){
    $designation = mysqli_real_escape_string($conn, $_GET['designation']);
    $where .= " AND designation = '$designation'";
}

$sql = "SELECT * FROM staff WHERE is_deleted=0 $where ORDER BY id DESC";
$res = mysqli_query($conn, $sql);
while($row = mysqli_fetch_assoc($res)){
    fputcsv($output, [
        $row['id'],
        $row['name'],
        $row['email'],
        $row['phone'],
        $row['designation'],
        $row['salary'],
        $row['image'],
        $row['created_at']
    ]);
}
fclose($output);
exit;
