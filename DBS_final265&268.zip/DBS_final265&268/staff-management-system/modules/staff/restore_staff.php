<?php
include "../../config/db.php";
include "../../includes/auth_check.php";
$id = $_GET['id'];

mysqli_query($conn, "UPDATE staff SET is_deleted = 0 WHERE id=$id");

header("Location: ../../pages/deleted_staff.php");
