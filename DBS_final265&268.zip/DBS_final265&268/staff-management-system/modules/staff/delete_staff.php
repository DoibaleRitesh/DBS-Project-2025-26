<?php
include "../../config/db.php";
include "../../includes/auth_check.php";
$id = $_GET['id'];

mysqli_query($conn, "UPDATE staff SET is_deleted = 1 WHERE id=$id");

header("Location: ../../pages/staff_list.php");
