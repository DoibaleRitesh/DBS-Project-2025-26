<?php
include "../../config/db.php";
include "../../includes/auth_check.php";

if(isset($_POST['add'])){
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $designation = mysqli_real_escape_string($conn, $_POST['designation']);
    $salary = floatval($_POST['salary']);

    // IMAGE UPLOAD with basic checks
    $imageName = 'default.png';
    if(!empty($_FILES['image']['name'])){
        $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        $allowed = ['png','jpg','jpeg','gif'];
        if(in_array($ext, $allowed)){
            $imageName = uniqid('emp_') . '.' . $ext;
            $target = "../../public/images/employees/" . $imageName;
            move_uploaded_file($_FILES['image']['tmp_name'], $target);
        }
    }

    $sql = "INSERT INTO staff(name,email,phone,designation,salary,image)
            VALUES(?,?,?,?,?,?)";
    $stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "ssssds", $name, $email, $phone, $designation, $salary, $imageName);
    mysqli_stmt_execute($stmt);


    header("Location: ../../pages/staff_list.php");
    exit;
}
header("Location: staff-management-system/pages/add_staff.php");
exit;
