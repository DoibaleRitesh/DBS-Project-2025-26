<?php
include "../../config/db.php";
include "../../includes/auth_check.php";
$id = $_GET['id'];

mysqli_query($conn, "DELETE FROM staff WHERE id=$id");

header("Location: ../../pages/deleted_staff.php");
