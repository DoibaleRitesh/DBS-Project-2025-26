<?php
include "../../config/db.php";
include "../../includes/auth_check.php";

if($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['id'])){
    $id = intval($_POST['id']);
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $designation = mysqli_real_escape_string($conn, $_POST['designation']);
    $salary = floatval($_POST['salary']);

    // handle image if uploaded
    if(!empty($_FILES['image']['name'])){
        $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        $allowed = ['png','jpg','jpeg','gif'];
        if(in_array($ext, $allowed)){
            $imageName = uniqid('emp_') . '.' . $ext;
            $target = "../../public/images/employees/" . $imageName;
            move_uploaded_file($_FILES['image']['tmp_name'], $target);

            // remove old image
            $old = mysqli_fetch_assoc(mysqli_query($conn, "SELECT image FROM staff WHERE id=$id"))['image'];
            if($old && $old !== 'default.png' && file_exists("../../public/images/employees/".$old)){
                @unlink("../../public/images/employees/".$old);
            }

            $sql = "UPDATE staff SET name=?, email=?, phone=?, designation=?, salary=?, image=? WHERE id=?";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "sssdssi", $name, $email, $phone, $designation, $salary, $imageName, $id);
            mysqli_stmt_execute($stmt);
        }
    } else {
        $sql = "UPDATE staff SET name=?, email=?, phone=?, designation=?, salary=? WHERE id=?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "sssdsi", $name, $email, $phone, $designation, $salary, $id);
        mysqli_stmt_execute($stmt);
    }

    header("Location: ../../pages/staff_list.php");
    exit;
}
header("Location: ../../pages/staff_list.php");
exit;
