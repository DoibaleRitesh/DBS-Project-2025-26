<?php
session_start();
if(isset($_SESSION['admin_id'])){
    header("Location: dashboard.php");
    exit;
}
include "../includes/header.php";
?>
<div class="container" style="max-width:480px;margin-top:60px;">
    <div class="card shadow">
        <div class="card-body">
            <h4 class="card-title mb-3">Admin Login</h4>
            <?php if(!empty($_SESSION['login_error'])): ?>
                <div class="alert alert-danger"><?= $_SESSION['login_error']; unset($_SESSION['login_error']); ?></div>
            <?php endif; ?>
            <form method="POST" action="../modules/auth/login.php">
                <div class="mb-2">
                    <input type="text" name="username" class="form-control" placeholder="Username" required>
                </div>
                <div class="mb-3">
                    <input type="password" name="password" class="form-control" placeholder="Password" required>
                </div>
                <button class="btn btn-primary w-100" type="submit">Login</button>
            </form>
        </div>
    </div>
</div>
<?php include "../includes/footer.php"; ?>
