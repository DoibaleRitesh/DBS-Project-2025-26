<?php
include "../includes/header.php";
include "../includes/navbar.php";
include "../includes/auth_check.php";
include "../config/db.php";

if(empty($_GET['id'])) { header("Location: staff_list.php"); exit; }
$id = intval($_GET['id']);
$res = mysqli_query($conn, "SELECT * FROM staff WHERE id=$id");
if(mysqli_num_rows($res)==0){ header("Location: staff_list.php"); exit; }
$row = mysqli_fetch_assoc($res);
?>
<div class="container mt-4">
    <h3>Edit Staff</h3>
    <form method="POST" action="../modules/staff/update_staff.php" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?= $row['id'] ?>">
        <div class="mb-2"><input type="text" name="name" class="form-control" value="<?= htmlspecialchars($row['name']) ?>" required></div>
        <div class="mb-2"><input type="email" name="email" class="form-control" value="<?= htmlspecialchars($row['email']) ?>" required></div>
        <div class="mb-2"><input type="text" name="phone" class="form-control" value="<?= htmlspecialchars($row['phone']) ?>"></div>
        <div class="mb-2"><input type="text" name="designation" class="form-control" value="<?= htmlspecialchars($row['designation']) ?>"></div>
        <div class="mb-2"><input type="number" step="0.01" name="salary" class="form-control" value="<?= htmlspecialchars($row['salary']) ?>"></div>
        <div class="mb-2">
            <label>Current Image</label><br>
            <img src="/public/images/employees/<?= htmlspecialchars($row['image']) ?>" width="100" onerror="this.src='../public/images/employees/default.png'">
        </div>
        <div class="mb-2">
            <label>Upload New Image (optional)</label>
            <input type="file" name="image" class="form-control">
        </div>
        <button class="btn btn-primary" type="submit">Update</button>
    </form>
</div>
<?php include "../includes/footer.php"; ?>
