<?php
include "../includes/header.php";
include "../includes/navbar.php";
include "../includes/auth_check.php";
include "../config/db.php";

// search & filter
$q = isset($_GET['q']) ? trim($_GET['q']) : '';
$designationFilter = isset($_GET['designation']) ? trim($_GET['designation']) : '';

// pagination
$perPage = 8;
$page = isset($_GET['page']) ? max(1,intval($_GET['page'])) : 1;
$offset = ($page-1)*$perPage;

// build where
$where = "WHERE is_deleted=0";
if($q !== '') {
    $esc = mysqli_real_escape_string($conn, $q);
    $where .= " AND (name LIKE '%$esc%' OR email LIKE '%$esc%' OR designation LIKE '%$esc%')";
}
if($designationFilter !== '') {
    $escD = mysqli_real_escape_string($conn, $designationFilter);
    $where .= " AND designation = '$escD'";
}

// total count
$rs = mysqli_query($conn, "SELECT COUNT(*) AS c FROM staff $where");
$total = mysqli_fetch_assoc($rs)['c'];
$pages = ceil($total / $perPage);

// fetch rows
$sql = "SELECT * FROM staff $where ORDER BY id DESC LIMIT $perPage OFFSET $offset";
$res = mysqli_query($conn, $sql);

// get distinct designations for filter dropdown
$desRes = mysqli_query($conn, "SELECT DISTINCT designation FROM staff WHERE designation IS NOT NULL AND designation!=''");

?>
<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>Staff List</h3>
        <div>
            <a href="../modules/staff/export_csv.php?q=<?= urlencode($q) ?>&designation=<?= urlencode($designationFilter) ?>" class="btn btn-outline-secondary btn-sm">Export CSV</a>
        </div>
    </div>

    <form class="row g-2 mb-3">
        <div class="col-sm-5">
            <input name="q" value="<?= htmlspecialchars($q) ?>" class="form-control" placeholder="Search name, email, designation...">
        </div>
        <div class="col-sm-3">
            <select name="designation" class="form-select">
                <option value="">-- All Designations --</option>
                <?php while($d = mysqli_fetch_assoc($desRes)): ?>
                    <option value="<?= htmlspecialchars($d['designation']) ?>" <?= ($designationFilter===$d['designation'])?'selected':'' ?>>
                        <?= htmlspecialchars($d['designation']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="col-sm-2">
            <button class="btn btn-primary">Search</button>
        </div>
    </form>

    <table class="table table-bordered table-striped">
        <tr class="table-dark">
            <th>Image</th><th>Name</th><th>Email</th><th>Designation</th><th>Salary</th><th>Actions</th>
        </tr>

    <?php while($row = mysqli_fetch_assoc($res)): ?>
        <tr>
            <td><img src="../public/images/employees/<?= htmlspecialchars($row['image']) ?>" width="70" onerror="this.src='../public/images/employees/default.png'"></td>
            <td><?= htmlspecialchars($row['name']) ?></td>
            <td><?= htmlspecialchars($row['email']) ?></td>
            <td><?= htmlspecialchars($row['designation']) ?></td>
            <td><?= htmlspecialchars($row['salary']) ?></td>
            <td>
                <a href="edit_staff.php?id=<?= $row['id'] ?>" class="btn btn-primary btn-sm">Edit</a>
                <a href="../modules/staff/delete_staff.php?id=<?= $row['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Move to deleted?')">Delete</a>
            </td>
        </tr>
    <?php endwhile; ?>
    </table>

    <?php if($pages > 1): ?>
    <nav>
      <ul class="pagination">
        <?php for($i=1;$i<=$pages;$i++): ?>
            <li class="page-item <?= $i==$page ? 'active' : '' ?>">
                <a class="page-link" href="?q=<?= urlencode($q) ?>&designation=<?= urlencode($designationFilter) ?>&page=<?= $i ?>"><?= $i ?></a>
            </li>
        <?php endfor; ?>
      </ul>
    </nav>
    <?php endif; ?>
</div>

<?php include "../includes/footer.php"; ?>
