<?php include "../includes/header.php"; ?>
<?php include "../includes/navbar.php"; ?>
<?php include "../config/db.php";
include "../includes/auth_check.php";
 ?>

<div class="container mt-4">
<h3>Deleted Staff</h3>

<table class="table table-bordered">
    <tr class="table-danger">
        <th>Image</th><th>Name</th><th>Email</th><th>Actions</th>
    </tr>

<?php
$res = mysqli_query($conn, "SELECT * FROM staff WHERE is_deleted=1");
while($row = mysqli_fetch_assoc($res)){ ?>
    
    <tr>
        <td><img src="../public/images/employees/<?= $row['image'] ?>" width="70"></td>
        <td><?= $row['name'] ?></td>
        <td><?= $row['email'] ?></td>

        <td>
            <a href="../modules/staff/restore_staff.php?id=<?= $row['id'] ?>" class="btn btn-success btn-sm">Restore</a>
            <a href="../modules/staff/permanent_delete.php?id=<?= $row['id'] ?>" class="btn btn-danger btn-sm">Delete Forever</a>
        </td>
    </tr>

<?php } ?>

</table>
</div>

<?php include "../includes/footer.php"; 

?>

