<?php
include "../includes/header.php";
include "../includes/navbar.php";
include "../includes/auth_check.php";
include "../config/db.php";

$total = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS c FROM staff WHERE is_deleted=0"))['c'];
$deleted = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS c FROM staff WHERE is_deleted=1"))['c'];
$designations = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(DISTINCT designation) AS c FROM staff"))['c'];
?>
<div class="container mt-4">
    <h3>Dashboard</h3>
    <div class="row">
        <div class="col-md-3">
            <div class="card p-3">
                <h5>Total Staff</h5>
                <h2><?= $total ?></h2>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card p-3">
                <h5>Deleted</h5>
                <h2><?= $deleted ?></h2>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card p-3">
                <h5>Designations</h5>
                <h2><?= $designations ?></h2>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card p-3">
                <h5>Quick Links</h5>
                <a href="add_staff.php" class="btn btn-sm btn-success mb-1">Add Staff</a>
                <a href="staff_list.php" class="btn btn-sm btn-primary mb-1">List View</a>
            </div>
        </div>
    </div>
</div>
<?php include "../includes/footer.php"; ?>
