<?php
include "../includes/header.php";
include "../includes/navbar.php";
include "../includes/auth_check.php";
include "../config/db.php";

$q = isset($_GET['q']) ? trim($_GET['q']) : '';
$designationFilter = isset($_GET['designation']) ? trim($_GET['designation']) : '';

$perPage = 8;
$page = isset($_GET['page']) ? max(1,intval($_GET['page'])) : 1;
$offset = ($page-1)*$perPage;

$where = "WHERE is_deleted=0";
if($q !== '') {
    $esc = mysqli_real_escape_string($conn, $q);
    $where .= " AND (name LIKE '%$esc%' OR email LIKE '%$esc%' OR designation LIKE '%$esc%')";
}
if($designationFilter !== '') {
    $escD = mysqli_real_escape_string($conn, $designationFilter);
    $where .= " AND designation = '$escD'";
}

$total = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS c FROM staff $where"))['c'];
$pages = ceil($total / $perPage);

$res = mysqli_query($conn, "SELECT * FROM staff $where ORDER BY id DESC LIMIT $perPage OFFSET $offset");
$desRes = mysqli_query($conn, "SELECT DISTINCT designation FROM staff WHERE designation IS NOT NULL AND designation!=''");

?>
<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>Staff Cards</h3>
        <a href="../modules/staff/export_csv.php?q=<?= urlencode($q) ?>&designation=<?= urlencode($designationFilter) ?>" class="btn btn-outline-secondary btn-sm">Export CSV</a>
    </div>

    <form class="row g-2 mb-3">
        <div class="col-sm-5">
            <input name="q" value="<?= htmlspecialchars($q) ?>" class="form-control" placeholder="Search...">
        </div>
        <div class="col-sm-3">
            <select name="designation" class="form-select">
                <option value="">-- All Designations --</option>
                <?php while($d = mysqli_fetch_assoc($desRes)): ?>
                    <option value="<?= htmlspecialchars($d['designation']) ?>" <?= ($designationFilter===$d['designation'])?'selected':'' ?>>
                        <?= htmlspecialchars($d['designation']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="col-sm-2">
            <button class="btn btn-primary">Search</button>
        </div>
    </form>

    <div class="row">
        <?php while($row = mysqli_fetch_assoc($res)): ?>
            <div class="col-md-3 mb-3">
                <div class="card h-100 shadow-sm">
                    <img src="../public/images/employees/<?= htmlspecialchars($row['image']) ?>" class="card-img-top" style="object-fit:cover;height:200px" onerror="this.src='../public/images/employees/default.png'">
                    <div class="card-body">
                        <h5 class="card-title"><?= htmlspecialchars($row['name']) ?></h5>
                        <p class="card-text"><?= htmlspecialchars($row['designation']) ?></p>
                        <p class="small"><?= htmlspecialchars($row['email']) ?></p>
                        <div class="d-flex justify-content-between">
                            <a href="edit_staff.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-primary">Edit</a>
                            <a href="../modules/staff/delete_staff.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Move to deleted?')">Delete</a>
                        </div>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    </div>

    <?php if($pages>1): ?>
      <nav>
        <ul class="pagination">
          <?php for($i=1;$i<=$pages;$i++): ?>
            <li class="page-item <?= $i==$page ? 'active' : '' ?>">
              <a class="page-link" href="?q=<?= urlencode($q) ?>&designation=<?= urlencode($designationFilter) ?>&page=<?= $i ?>"><?= $i ?></a>
            </li>
          <?php endfor; ?>
        </ul>
      </nav>
    <?php endif; ?>

</div>

<?php include "../includes/footer.php"; ?>
