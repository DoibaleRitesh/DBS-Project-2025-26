<?php include "../includes/header.php"; ?>
<?php include "../includes/navbar.php"; ?>

<div class="container mt-4">
    <h3>Add Staff</h3>

    <form action="../modules/staff/add_staff.php" method="POST" enctype="multipart/form-data">

        <input type="text" name="name" class="form-control mb-2" placeholder="Full Name" required>

        <input type="email" name="email" class="form-control mb-2" placeholder="Email" required>

        <input type="text" name="phone" class="form-control mb-2" placeholder="Phone">

        <input type="text" name="designation" class="form-control mb-2" placeholder="Designation">

        <input type="number" name="salary" class="form-control mb-2" placeholder="Salary">

        <input type="file" name="image" class="form-control mb-2" required>

        <button type="submit" name="add" class="btn btn-success">Add Staff</button>
    </form>
</div>

<?php include "../includes/footer.php"; ?>
