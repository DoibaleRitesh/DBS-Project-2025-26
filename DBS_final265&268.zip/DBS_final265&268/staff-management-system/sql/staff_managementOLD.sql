CREATE DATABASE IF NOT EXISTS staff_management;
USE staff_management;

CREATE TABLE staff (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE,
    phone VARCHAR(20),
    designation VARCHAR(100),
    salary DECIMAL(10,2),
    image VARCHAR(255) DEFAULT 'default.png',
    is_deleted TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


-- add admin table and a default admin user (password is 'admin123' hashed)
CREATE TABLE IF NOT EXISTS admin (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- insert default admin if not exists
INSERT INTO admin (username, password)
SELECT 'admin', SHA2('admin123',256)
WHERE NOT EXISTS (SELECT 1 FROM admin WHERE username='admin');

-- sample staff (optional)
INSERT INTO staff (name,email,phone,designation,salary,image)
VALUES
('Asha Patel','asha@example.com','9876543210','Designer',35000,'default.png'),
('Ravi Kumar','ravi@example.com','9123456780','Developer',45000,'default.png');
