<?php
if(session_status() == PHP_SESSION_NONE) session_start();
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="../index.php">StaffManager</a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navMenu">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item"><a class="nav-link" href="../pages/staff_list.php">List View</a></li>
        <li class="nav-item"><a class="nav-link" href="../pages/staff_cards.php">Card View</a></li>
        <li class="nav-item"><a class="nav-link" href="../pages/add_staff.php">Add Staff</a></li>
        <li class="nav-item"><a class="nav-link" href="../pages/deleted_staff.php">Deleted</a></li>
      </ul>

      <div class="d-flex align-items-center">
        <?php if(isset($_SESSION['admin_user'])): ?>
            <span class="text-light me-2">Hi, <?= htmlspecialchars($_SESSION['admin_user']); ?></span>
            <a href="../modules/auth/logout.php" class="btn btn-sm btn-danger">Logout</a>
        <?php else: ?>
            <a href="/pages/login.php" class="btn btn-sm btn-success">Login</a>
        <?php endif; ?>
      </div>
    </div>
  </div>
</nav>

<script>
document.addEventListener('DOMContentLoaded', function() {
  const btn = document.getElementById('darkToggle');
  const current = localStorage.getItem('sm_theme') || 'light';
  if(current === 'dark') document.documentElement.classList.add('dark-mode');

  btn.addEventListener('click', () => {
    document.documentElement.classList.toggle('dark-mode');
    const now = document.documentElement.classList.contains('dark-mode') ? 'dark' : 'light';
    localStorage.setItem('sm_theme', now);
  });
});
</script>
